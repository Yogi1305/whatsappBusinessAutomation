import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock } from 'lucide-react';
import { InlineWidget } from 'react-calendly';

const CalendlySection = () => {
  return (
    <section className="py-20 bg-gradient-to-r from-green-50 to-blue-50 relative overflow-hidden">
      <motion.div
        className="absolute top-10 left-10 w-20 h-20 bg-green-200 rounded-full opacity-50"
        animate={{ y: [0, 20, 0] }}
        transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute bottom-10 right-10 w-16 h-16 bg-blue-200 rounded-full opacity-50"
        animate={{ y: [0, -20, 0] }}
        transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
      />
      
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-5xl font-bold text-gray-800 mb-4">Schedule a Personalized Demo</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Experience the power of NurenAI firsthand. Book a slot for an online meeting with our experts and discover how we can transform your WhatsApp business communication.
          </p>
        </motion.div>
        
        <div className="flex flex-col md:flex-row items-center justify-between">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="w-full md:w-1/2 mb-8 md:mb-0"
          >
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <div className="flex items-center mb-6">
                <Calendar className="w-8 h-8 text-green-500 mr-4" />
                <h3 className="text-2xl font-bold text-gray-800">Easy Scheduling</h3>
              </div>
              <p className="text-gray-600 mb-6">
                Choose a date and time that works best for you. Our calendar is updated in real-time to show you our available slots.
              </p>
              <div className="flex items-center">
                <Clock className="w-8 h-8 text-green-500 mr-4" />
                <h3 className="text-2xl font-bold text-gray-800">30-Minute Demo</h3>
              </div>
              <p className="text-gray-600 mt-2">
                In just 30 minutes, we'll showcase NurenAI's features and answer any questions you may have.
              </p>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="w-full md:w-1/2 md:pl-8"
          >
            {/* <div className="calendly-inline-widget" data-url="https://calendly.com/kumar-ayush121564/30min" style={{ minWidth: '320px', height: '630px' }}></div> */}
            <InlineWidget styles={{
  height: '1000px'
}} url="https://calendly.com/kumar-ayush121564/30min" />

          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default CalendlySection;